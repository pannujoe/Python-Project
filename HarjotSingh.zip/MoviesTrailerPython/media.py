"""
this module contains the movie class that will be used in the
media movie_center.py file
"""


class Movie():

    """
    Following is the list of information created in class to display 
    fav movies information on HTML page.
    """
    def __init__(self, title, logo, trailer, director, actors, release):
        self.title = title
        self.logo = logo
        self.trailer_url = trailer
        self.director = director
        self.actors = actors
        self.release_date = release
        
