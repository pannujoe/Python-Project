"""
list of movies that feed into fresh_tomatoes.py file

"""
import media
import fresh_tomatoes



AVATAR = media.Movie( "Avatar",
                      "https://upload.wikimedia.org/wikipedia/en/b/b0/Avatar-Teaser-Poster.jpg",
                      "https://www.youtube.com/watch?v=5PSNL1qE6VY",
                      "Mark Cardellio",
                      "Sam Worthington, Zoe Saldana, Stephen Lang",
                      "2009")

AMERICAN_PSYCHO = media.Movie("American Psycho",
                              "https://upload.wikimedia.org/wikipedia/en/"
                              "thumb/6/63/Americanpsychoposter.jpg/"
                              "220px-Americanpsychoposter.jpg",
                              "https://www.youtube.com/watch?v=2GIsExb5jJU",
                              "Mary Harron",
                              "Christian Bale, Justin Theroux, Josh Lucas",
                              "2000")

FROZEN = media.Movie("Frozen",
                     "https://upload.wikimedia.org/wikipedia/en/0/05/Frozen_%282013_film%29_poster.jpg",
                     "https://www.youtube.com/watch?v=TbQm5doF_Uc",
                     "Hans Christian Andersen",
                     "Kristen Bell ",
                     "2009")



BROKEN_FLOWERS = media.Movie("Broken Flowers",
                             "https://upload.wikimedia.org/wikipedia/en/"
                             "thumb/7/79/Broken_Flowers_poster.jpg/"
                             "220px-Broken_Flowers_poster.jpg",
                             "https://www.youtube.com/watch?v=c_TB7MkrGyc",
                             "Jim Jarmusch",
                             "Bill Murray, Jessica Lange, Sharon Stone",
                             "2005")

DARJEELING_LIMITED = media.Movie("Darjeeling Limited",
                                 "https://upload.wikimedia.org/wikipedia/en/"
                                 "thumb/1/1e/Darjeeling_Limited_Poster.jpg/"
                                 "220px-Darjeeling_Limited_Poster.jpg",
                                 "https://www.youtube.com/watch?v=aO1bYukdvLI",
                                 "Wes Anderson",
                                 "Owen Wilson, Adrien Brody,\
                                  Jason Schwartzman",
                                 "2007")

EDWARD_SCISSORHANDS = media.Movie("Edward Scissorhands",
                                  "https://upload.wikimedia.org/wikipedia/en/"
                                  "thumb/3/3b/Edwardscissorhandsposter.JPG/"
                                  "220px-Edwardscissorhandsposter.JPG",
                                  "https://www.youtube.com/"
                                  "watch?v=M94yyfWy-KI",
                                  "Tim Burton",
                                  "Johnny Depp, Winona Ryder, Dianne Wiest",
                                  "1990")

EYES_WIDE_SHUT = media.Movie("Eyes Wide Shut",
                             "https://upload.wikimedia.org/wikipedia/en/"
                             "thumb/c/c3/Ghostworldposter.jpg/"
                             "215px-Ghostworldposter.jpg",
                             "https://www.youtube.com/watch?v=YEfyfcEdW4Y",
                             "Stanley Kubrick",
                             "Tom Cruise, Nicole Kidman, Todd Field",
                             "1999")

GHOST_WORLD = media.Movie("Ghost World",
                          "https://upload.wikimedia.org/wikipedia/en/"
                          "thumb/8/87/Eyes_Wide_Shut_poster.jpg/"
                          "220px-Eyes_Wide_Shut_poster.jpg",
                          "https://www.youtube.com/watch?v=YEfyfcEdW4Y",
                          "Terry Zwigoff",
                          "Steve Buscemi, Thora Birch, Scarlett Johansson",
                          "2001")

GOODFELLAS = media.Movie("Goodfellas",
                         "https://upload.wikimedia.org/wikipedia/en/"
                         "thumb/7/7b/Goodfellas.jpg/"
                         "220px-Goodfellas.jpg",
                         "https://www.youtube.com/watch?v=2ilzidi_J8Q",
                         "Martin Scorsese",
                         "Robert De Niro, Ray Liotta, Joe Pesci",
                         "1990")

GRAND_BUDAPEST_HOTEL = media.Movie("Grand Budapest Hotel",
                                   "https://upload.wikimedia.org/wikipedia/en/"
                                   "thumb/a/a6/"
                                   "The_Grand_Budapest_Hotel_Poster.jpg/"
                                   "220px-The_Grand_Budapest_Hotel_Poster.jpg",
                                   "https://www.youtube.com/"
                                   "watch?v=1Fg5iWmQjwk",
                                   "Wes Anderson",
                                   "Ralph Fiennes, F. Murray Abraham,\
                                    Mathieu Amalric",
                                   "2014")

HOLY_MOUNTAIN = media.Movie("Holy Mountain",
                            "https://upload.wikimedia.org/wikipedia/en/"
                            "thumb/3/39/Holy_Mountain.gif/"
                            "220px-Holy_Mountain.gif",
                            "https://www.youtube.com/watch?v=V_k8oaeHsnc",
                            "Alejandro Jodorowsky",
                            "Alejandro Jodorowsky, Horacio Salinas, Zamira",
                            "1973")

HOT_FUZZ = media.Movie("Hot fuzz",
                       "https://upload.wikimedia.org/wikipedia/en/"
                       "thumb/c/c9/HotFuzzUKposter.jpg/"
                       "250px-HotFuzzUKposter.jpg",
                       "https://www.youtube.com/watch?v=ayTnvVpj9t4",
                       "Edgar Wright",
                       "Simon Pegg, Nick Frost, Martin Freeman",
                       "2007")

IDIOCRACY = media.Movie("Idiocracy",
                        "https://upload.wikimedia.org/wikipedia/en/"
                        "6/6b/Idiocracy_movie_poster.jpg",
                        "https://www.youtube.com/watch?v=BBvIweCIgwk",
                        "Mike Judge",
                        "Luke Wilson, Maya Rudolph, Dax Shepard",
                        "2006")

IN_A_WORLD = media.Movie("In a World",
                         "https://upload.wikimedia.org/wikipedia/en/"
                         "thumb/4/49/In_a_World_poster.jpg/"
                         "220px-In_a_World_poster.jpg",
                         "https://www.youtube.com/watch?v=bZHBjLFu5is",
                         "Lake Bell",
                         "Lake Bell, Fred Melamed, Michaela Watkins",
                         "2013")

                          
         

movies = [AVATAR, 
          AMERICAN_PSYCHO,
          FROZEN,  
          BROKEN_FLOWERS, 
          DARJEELING_LIMITED,
          EDWARD_SCISSORHANDS, 
          EYES_WIDE_SHUT, 
          GHOST_WORLD, GOODFELLAS,
          GRAND_BUDAPEST_HOTEL, 
          HOLY_MOUNTAIN, 
          HOT_FUZZ, 
          IDIOCRACY,
          IN_A_WORLD]

fresh_tomatoes.open_movies_page(movies)
